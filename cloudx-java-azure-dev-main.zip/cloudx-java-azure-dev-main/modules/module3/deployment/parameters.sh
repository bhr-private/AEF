#!/bin/bash
appName="petstore"
location="eastus"
rgName=${appName}rg
appInsightsName=${appName}-insights
containerRegistryName=contreg${appName}
