1. Modify `deploy-app-service.sh` to accept location. Required to deploy the same app twice in different locations
2. Add deployment of the Traffic Manager